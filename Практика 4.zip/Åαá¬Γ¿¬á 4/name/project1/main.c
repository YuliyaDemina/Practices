#include <8051.h>
unsigned char* init()
{
	unsigned char array[7];
	array[0]=0x0; 
	array[1]=0x80; //T=3s 
	array[2]=0x40; //T=3s
	array[3]=0x30; //T=5s
	array[4]=0xC; //T=5s
	array[5]=0x2; //T=3s
	array[6]=0x1; //T=3s
	return array;
}
void msec (int x) 
{
	while(x-->0) 
	{
		TH0 = (-10000)>>8;
		TL0=-10000;  
		TR0=1;
		do;
		while(TF0==0); 
		TF0=0; 
		TR0=0; 
	}
}
void main() 
{
	int i;
	unsigned char*array=init();
	TMOD=0x1; 
	while(1)
	{
		P1=0;
		msec(1);
 		P1=255;
		msec(1);
 		P1=0;
		msec(1);
 		for(i=1;i<=22;i++) 
		{
			P1=0;
			if(i<=3) P1=128;
			else if(i<=6 && i>3) P1=array[2];
			else if(i<=11 && i>6) P1=array[3];
			else if(i<=16 && i>11) P1=array[4];
			else if(i<=19 && i>16) P1=array[5];
			else if (i>19)P1=array[6];
			msec(1);
		}
		
	}
}
