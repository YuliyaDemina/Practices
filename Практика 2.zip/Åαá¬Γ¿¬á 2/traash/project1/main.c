#include <8051.h>
void main()
{
unsigned char i,j; 
unsigned char massiv [11]=
{
0x90,//9
0x80,//8
0xF8,//7
0x82,//6
0x92,//5
0x99,//4
0xB0,//3
0xA4,//2
0xF9,//1
0xC0,//0 
0xFF // OFF
};
P10=0;

while(1)
{
	if(P10>0)
	{
		break;
	}
}
for(i=0;i<10;i=i+2) 
{
P2=massiv[i]; 
for(j=0;j<100;j++)
continue;
}
P2=massiv[10]; 
while(1);
}
